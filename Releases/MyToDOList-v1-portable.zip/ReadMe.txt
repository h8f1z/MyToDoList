#MyToDoList
-----------

This freeware is a simple todo list manager for windows. 

Why a todo list?  
'Cuz life's more than just "wake up, survive, go back to sleep".   
[  ] Plan,   
[  ] accomplish,     
[  ] see how far you've gone...  
[  ] get motivated.   
[  ] Then do more...  


Basic functions include:  
- Add New task: `Ctrl + N`
- Remove selected task: `Del`
- Remove tasks that are done (checked): `Shift + Ctrl + Del`  


-----  

> If you have installed **MyToDoList**, the "list" (file that stores tasks) is 
in 'My documents': more precisely ` %userprofile%\Documents `  

------  

> If  you're using portable version, file will be saved in the 
same location as the app is running. 
> DO NOT DELETE THE **MyToDoList.mtdl**, unless you want to remove the entire todo list...

-----  

Feel free to share this app, but do not modify any part of it.

Request any changes that are required or any bugs, if found: 
https://t.me/dev_fixxy

Have a good day... :)

-----